
<?php $__env->startSection('content'); ?>

			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10" style="height: 100vh">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Dashboard</a></li>
			</ul>

			<div class="row-fluid">
				
				<div class="span3 statbox purple" onTablet="span6" onDesktop="span3">
					
					<div class="number"><?php echo $total_news; ?><i class="icon-arrow-up"></i></div>
					<div class="title">News</div>
					
				</div>
				<div class="span3 statbox green" onTablet="span6" onDesktop="span3">
					<div class="number"><?php echo $total_user; ?><i class="icon-arrow-up"></i></div>
					<div class="title">User</div>
					
				</div>
				<div class="span3 statbox blue noMargin" onTablet="span6" onDesktop="span3">
					<div class="number"><?php echo $total_comment; ?><i class="icon-arrow-up"></i></div>
					<div class="title">Comment</div>
					
				</div>
				<div class="span3 statbox yellow" onTablet="span6" onDesktop="span3">
					<div class="number"><?php echo $total_cat; ?><i class="icon-arrow-down"></i></div>
					<div class="title">Category</div>
					
				</div>	
				
			</div>		

			
			
						
			
			
			
					
			
			
			
       

	</div><!--/.fluid-container-->
			<!-- end: Main Menu -->
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('loginmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/News_Blog/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>