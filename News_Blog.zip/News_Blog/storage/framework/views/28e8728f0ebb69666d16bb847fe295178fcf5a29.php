<?php echo $__env->yieldContent('header'); ?>

        <!-- Nav Bar End -->

        <!-- Top News Start-->
       <?php echo $__env->yieldContent('body'); ?>
        <!-- Main News End-->
        <?php echo $__env->yieldContent('footer'); ?>
<?php /**PATH /opt/lampp/htdocs/News_Blog/resources/views/master.blade.php ENDPATH**/ ?>