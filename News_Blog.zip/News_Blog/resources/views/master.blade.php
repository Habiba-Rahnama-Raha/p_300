@yield('header')

        <!-- Nav Bar End -->

        <!-- Top News Start-->
       @yield('body')
        <!-- Main News End-->
        @yield('footer')
